<html>
<!--- Questo programma viene distribuito dall'autore Antonio Broi http://www.broi.it broi.antonio@gmail.com
        con licenza di tipo:

LICENZA CREATIVE COMMONS
ATTRIBUZIONE - NON COMMERCIALE - CONDIVIDI ALLO STESSO MODO 3.0 Italia
(CC BY-NC-SA 3.0 IT)

Tu sei libero:

di riprodurre, distribuire, comunicare al pubblico, esporre in pubblico, rappresentare, eseguire e recitare quest'opera
di modificare quest'opera

Alle seguenti condizioni:

Attribuzione � Devi attribuire la paternit�ell'opera nei modi indicati dall'autore o da chi ti ha dato l'opera in licenza e in modo tale da non suggerire che essi avallino te o il modo in cui tu usi l'opera.

Attribuisci quest'opera:

Che cosa significa "Dai credito a questo lavoro"?

La pagina da cui provieni conteneva metadati relativi ad una licenza, incluso come il creatore desidera ricevere credito in caso di riuso dell'opera.

Puoi utilizzare il codice HTML fornito qui per citare l'opera.

Cos�acendo includereai anche metadati nella tua pagina, che altri potranno utilizzare per trovare l'opera originale.

Non commerciale �

Non puoi usare quest'opera per fini commerciali.

Condividi allo stesso modo � Se alteri o trasformi quest'opera, o se la usi per crearne un'altra, puoi distribuire l'opera risultante solo con una licenza identica o equivalente a questa.

Prendendo atto che:

Rinuncia � E' possibile rinunciare a qualunque delle condizioni sopra descritte se ottieni l'autorizzazione dal detentore dei diritti.

Pubblico Dominio � Nel caso in cui l'opera o qualunque delle sue componenti siano nel pubblico dominio secondo la legge vigente, tale condizione non �n alcun modo modificata dalla licenza.

Altri Diritti � La licenza non ha effetto in nessun modo sui seguenti diritti:

�Le eccezioni, libere utilizzazioni e le altre utilizzazioni consentite dalla legge sul diritto d'autore;
�I diritti morali dell'autore;
�Diritti che altre persone possono avere sia sull'opera stessa che su come l'opera viene utilizzata, come il diritto all'immagine o alla tutela dei dati personali.

Nota � Ogni volta che usi o distribuisci quest'opera, devi farlo secondo i termini di questa licenza, che va comunicata con chiarezza.
--->
<head> <title> D I S A L L O W    </title>
</head>
<body bgcolor="#0099ff" text="white" background="">
<table border="3" width="100%" height="10%">

<tr>

<td width="90%" bgcolor="transparent" text="white"><h1>Investigative Tool's</h1></td>

<td width="10%" bgcolor="transparent">    <a href=http://www.broi.it> <center> <img src="terrina.jpg" alt="Come back" title="Come back"  position="center" /></center> </a>

</td>

</tr>

</table>


<form>

1) Scegli il nome di un quotidiano dal menu a tendina  <br>
2) Oppure inserisci un nome di dominio completo es. "http://www.microsoft.com" <br>
. . . . .  e scegli "INPUT"  <br>

<input type="submit" value="SCEGLI E CLICCA" >


<input type="text" name="n2">


<select name="n1">
<option>INPUT
<option>avvenire_ITALY
<option>asahi_JAPAN
<option>berliner_morgenpost_GERMANY
<option>corriere_della_sera_ITALY
<option>facebook
<option>herald_tribune_USA
<option>il_fatto_quotidiano_ITALY
<option>il_giornale_ITALY
<option>il_foglio_ITALY
<option>il_manifesto_ITALY
<option>il_mattino_ITALY
<option>il_messaggero_ITALY
<option>il_sole_24_ore_ITALY
<option>il_tempo_ITALY
<option>italia_oggi_ITALY
<option>nepal_homepage_NEPAL
<option>la_nuova_sardegna_ITALY
<option>la_stampa_ITALY
<option>la_gazzetta_dello_sport_ITALY
<option>le_monde_FRANCE
<option>le_figaro_FRANCE
<option>libero_ITALY
<option>microsoft
<option>new_york_times_USA
<option selected>repubblica_ITALY
<option>the_times_UK
<option>the_sun_UK
<option>twitter
<option>unione_sarda_ITALY
<option>unita_ITALY
<option>wall_street_journal_USA
<option>washington_post_USA
<option>wikipedia



</select>


<br> <br><br> <br>
<br> <br>

</form>

<?php
$sit="";

$ni=@$_GET["n1"];
$n2=@$_GET["n2"];

switch ($ni)
{
   case "INPUT";
   {
     $sit=$n2;
     $sitoArr= file($n2.'/robots.txt');
      break;
   }
   case "avvenire_ITALY";
   {
     $sit='http://www.avvenire.it';
     $sitoArr= file('http://www.avvenire.it/robots.txt');
      break;
   }

   case "repubblica_ITALY";
   {
     $sit='http://www.repubblica.it';
     $sitoArr= file('http://www.repubblica.it/robots.txt');
      break;
   }
   case "il_giornale_ITALY";
   {
     $sit='http://www.ilgiornale.it';
     $sitoArr= file('http://www.ilgiornale.it/robots.txt');
      break;
   }

   case "herald_tribune_USA";
   {
     $sit='http://global.nytimes.com';
     $sitoArr= file('http://global.nytimes.com/robots.txt');
      break;
   }
   case "corriere_della_sera_ITALY";
   {
     $sit='http://www.corriere.it';
     $sitoArr= file('http://www.corriere.it/robots.txt');
      break;
   }
     case "il_fatto_quotidiano_ITALY";
   {
     $sit='http://www.ilfattoquotidiano.it';
     $sitoArr= file('http://www.ilfattoquotidiano.it/robots.txt');
      break;
   }

   case "la_nuova_sardegna_ITALY";
   {
     $sit='http://lanuovasardegna.gelocal.it';
     $sitoArr= file('http://lanuovasardegna.gelocal.it/robots.txt');
      break;
   }

     case "il_mattino_ITALY";
   {
     $sit='http://www.ilmattino.it';
     $sitoArr= file('http://www.ilmattino.it/robots.txt');
      break;
   }

   case "unione_sarda_ITALY";
   {
     $sit='http://www.unionesarda.it';
     $sitoArr= file('http://www.unionesarda.it/robots.txt');
      break;
   }
     case "il_sole_24_ore_ITALY";
   {
     $sit='http://www.ilsole24ore.it';
     $sitoArr= file('http://www.ilsole24ore.it/robots.txt');
      break;
   }
     case "new_york_times_USA";
   {
     $sit='http://www.nytimes.com';
     $sitoArr= file('http://www.nytimes.com/robots.txt');
      break;
   }
   case "il_manifesto_ITALY";
   {
     $sit='http://www.ilmanifesto.it';
     $sitoArr= file('http://www.ilmanifesto.it/robots.txt');
      break;
      }
   case "la_gazzetta_dello_sport_ITALY";
   {
     $sit='http://www.gazzetta.it';
     $sitoArr= file('http://www.gazzetta.it/robots.txt');
      break;
      }
   case "libero_ITALY";
   {
     $sit='http://www.libero.it';
     $sitoArr= file('http://www.libero.it/robots.txt');
      break;
      }
   case "il_foglio_ITALY";
   {
     $sit='http://www.ilfoglio.it';
     $sitoArr= file('http://www.ilfoglio.it/robots.txt');
      break;
      }
      case "la_stampa_ITALY";
   {
     $sit='http://www.lastampa.it';
     $sitoArr= file('http://www.lastampa.it/robots.txt');
      break;
      }
       case "il_messaggero_ITALY";
   {
     $sit='http://www.ilmessaggero.it';
     $sitoArr= file('http://www.ilmessaggero.it/robots.txt');
      break;
      }

       case "italia_oggi_ITALY";
   {
     $sit='http://www.italiaoggi.it';
     $sitoArr= file('http://www.italiaoggi.it/robots.txt');
      break;
      }

       case "il_tempo_ITALY";
   {
     $sit='http://www.iltempo.it';
     $sitoArr= file('http://www.iltempo.it/robots.txt');
      break;
      }
     case "unita_ITALY";
   {
     $sit='http://www.unita.it';
     $sitoArr= file('http://www.unita.it/robots.txt');
      break;
      }

     case "wall_street_journal_ITALY";
   {
     $sit='http://europe.wsj.com';
     $sitoArr= file('http://europe.wsj.com/robots.txt');
      break;
      }

      case "wikipedia_ITALY";
   {
     $sit='http://en.wikipedia.org';
     $sitoArr= file('http://en.wikipedia.org/robots.txt');
      break;
      }
     case "facebook";
   {
     $sit='https://www.facebook.com';
     $sitoArr= file('https://www.facebook.com/robots.txt');
      break;
      }
      case "le_monde_FRANCE";
   {
     $sit='http://www.lemonde.fr';
     $sitoArr= file('http://www.lemonde.fr/robots.txt');
      break;
      }
      case "le_figaro_FRANCE";
   {
     $sit='http://www.lefigaro.fr';
     $sitoArr= file('http://www.lefigaro.fr/robots.txt');
      break;
      }
      case "the_times_UK";
   {
     $sit='http://www.thetimes.co.uk';
     $sitoArr= file('http://www.thetimes.co.uk/robots.txt');
      break;
      }

      case "the_sun_UK";
   {
     $sit='http://www.thesun.co.uk';
     $sitoArr= file('http://www.thesun.co.uk/robots.txt');
      break;
      }

    case "berliner_morgenpost_GERMANY";
   {
     $sit='http://www.morgenpost.de';
     $sitoArr= file('http://www.morgenpost.de/robots.txt');
      break;
      }
////////////////////////////////////////////////////////////////////
    case "microsoft";
   {
     $sit='http://www.microsoft.com';
     $sitoArr= file('http://www.microsoft.com/robots.txt');
      break;
      }
	  case "twitter";
   {
     $sit='https://www.twitter.com';
     $sitoArr= file('https://www.twitter.com/robots.txt');
      break;
      }

    case "washington_post_USA";
   {
     $sit='http://www.washingtonpost.com';
     $sitoArr= file('http://www.washingtonpost.com/robots.txt');
      break;
      }

    case "asahi_JAPAN";
   {
     $sit='http://www.asahi.com';
     $sitoArr= file('http://www.asahi.com/robots.txt');
      break;
      }

         case "nepal_homepage_NEPAL";
   {
     $sit='http://www.nepalhomepage.com';
     $sitoArr= file('http://www.nepalhomepage.com/robots.txt');
      break;
      }

}

#Array in stringa
@$sitoString=implode("###",$sitoArr);

#tolgo gli spazi dalla stringa
@$sitoStringSpazi= ereg_replace('[[:space:]]+','',trim($sitoString));

#sostituisci ll valore ACAP disallow con http://www.xxx.xx
@$sitoStringSpaziAcDis= str_replace("ACAP-disallow-crawl:",$sit,$sitoStringSpazi);

#sostituisci ll valore disallow con http://www.xxx.xx
@$sitoStringSpaziDis= str_replace("Disallow:",$sit,$sitoStringSpaziAcDis);

#rimetto tutto dentro un array
$sitoAr=explode("###",$sitoStringSpaziDis);

//////////////////////////////////////////////////////////////////////////////

@$needle=$sit;
$matches= array();

#print_r ($sitoAr);
 ############################################
 # cerca nell'array in modo ricorsivo e metti i risultati in array $matches
#$iterator = new RecursiveIteratorIterator (new RecursiveArrayIterator($sitoAr));
# foreach ($iterator as $value)
#       {
#    if(preg_match('/$needle/i',$value))
#        {
#    $matches[]=$value;
#
#        }
#
#        }
//////////////////////////////////////////////////////////////////////////////

echo "ELENCO SITI IN DISALLOW DAL SITO :  ".$sit."<table text='white' border='1' bgcolor='#0099ff'>";

for ($i=0;$i<count($sitoAr);$i++)
       {
 echo "<tr><td><tr><td><a href=$sitoAr[$i] target=_blank>".$sitoAr[$i]."</a>===>>>&nbsp".$sitoAr[$i]."</td></tr>";
        }
echo"</table>";
  ?>

<br><br><br><br><br>
<?php

$data=(date("d-m-y"));
echo "<br>";
echo "<table width='100%' border='3' >"."<tr><td width=30% align='left'>"."<b>"."<i>"."<font color='white' size='2'>".
" LICENZE CREATIVE COMMONS;&copy Antonio Broi"."</i>"."</b>"."</font>"."</td>".
"<td width='40%' align='center'>"."<font color='white' size='2'>";

echo "</td>";
echo "<td width='30%'>"."<font color='white' size='2'>";
echo" Oggi &egrave il giorno  : ".$data."&nbsp";
echo" e sono le ore ";
echo(date("G:i"));
echo "</td>".
"</tr>"."</font>"."</i>"."</b>".
"</table>";
?>

</body>
</html>
