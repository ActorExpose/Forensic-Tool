//---------------------------------------------------------------------------\
// This is a derivative of testipp.c from the CUPS project http://cups.org
// Modifications by Jake Cunningham
// jakec76@users.sourceforge.net
// http://jafat.sourceforge.net
//---------------------------------------------------------------------------\

#include <stdio.h>
#include <stdlib.h>
#include <cups/ipp.h>
#include <errno.h>
#include <fcntl.h>
#include "cups_control.h"

void	print_attributes(ipp_t *ipp, int indent);

int				/* O - Exit status */
main(int  argc,			/* I - Number of command-line arguments */
     char *argv[])		/* I - Command-line arguments */
{
int i;
int fd;

  ipp_t		*request;	/* Request */
  ipp_state_t	state;		/* State */

  if (argc < 2) {
     print_usage();
  }

  for (i = 1; i < argc; i ++)
  {
    if ((fd = open(argv[i], O_RDONLY)) < 0)
    {
      printf("Unable to open \"%s\" - %s\n", argv[i], strerror(errno));
      continue;
    }

    request = ippNew();
    while ((state = ippReadFile(fd, request)) == IPP_ATTRIBUTE);

    if (state != IPP_DATA)
      printf("Error reading IPP message from \"%s\"!\n", argv[i]);
    else
    {
      printf("\n%s:\n", argv[i]);
      print_attributes(request, 4);
    }

    ippDelete(request);
    close(fd);
  }

  return (0);
}

/*
 * 'print_attributes()' - Print the attributes in a request...
 */

void
print_attributes(ipp_t *ipp,		/* I - IPP request */
                 int   indent)		/* I - Indentation */
{
  int			i;		/* Looping var */
  ipp_tag_t		group;		/* Current group */
  ipp_attribute_t	*attr;		/* Current attribute */
  ipp_value_t		*val;		/* Current value */
  //
  int comparison1;
  int comparison2;
  int comparison3;
  char cmp_string1[] = "time-at-creation";
  char cmp_string2[] = "time-at-processing";
  char cmp_string3[] = "time-at-completed";
  //
  static const char * const tags[] =	/* Value/group tag strings */
			{
			  "reserved-00",
			  "operation-attributes-tag",
			  "job-attributes-tag",
			  "end-of-attributes-tag",
			  "printer-attributes-tag",
			  "unsupported-attributes-tag",
			  "subscription-attributes-tag",
			  "event-attributes-tag",
			  "reserved-08",
			  "reserved-09",
			  "reserved-0A",
			  "reserved-0B",
			  "reserved-0C",
			  "reserved-0D",
			  "reserved-0E",
			  "reserved-0F",
			  "unsupported",
			  "default",
			  "unknown",
			  "no-value",
			  "reserved-14",
			  "not-settable",
			  "delete-attr",
			  "admin-define",
			  "reserved-18",
			  "reserved-19",
			  "reserved-1A",
			  "reserved-1B",
			  "reserved-1C",
			  "reserved-1D",
			  "reserved-1E",
			  "reserved-1F",
			  "reserved-20",
			  "integer",
			  "boolean",
			  "enum",
			  "reserved-24",
			  "reserved-25",
			  "reserved-26",
			  "reserved-27",
			  "reserved-28",
			  "reserved-29",
			  "reserved-2a",
			  "reserved-2b",
			  "reserved-2c",
			  "reserved-2d",
			  "reserved-2e",
			  "reserved-2f",
			  "octetString",
			  "dateTime",
			  "resolution",
			  "rangeOfInteger",
			  "begCollection",
			  "textWithLanguage",
			  "nameWithLanguage",
			  "endCollection",
			  "reserved-38",
			  "reserved-39",
			  "reserved-3a",
			  "reserved-3b",
			  "reserved-3c",
			  "reserved-3d",
			  "reserved-3e",
			  "reserved-3f",
			  "reserved-40",
			  "textWithoutLanguage",
			  "nameWithoutLanguage",
			  "reserved-43",
			  "keyword",
			  "uri",
			  "uriScheme",
			  "charset",
			  "naturalLanguage",
			  "mimeMediaType",
			  "memberName"
			};


  for (group = IPP_TAG_ZERO, attr = ipp->attrs; attr; attr = attr->next)
  {
    if (attr->group_tag == IPP_TAG_ZERO || !attr->name)
    {
      group = IPP_TAG_ZERO;
      putchar('\n');
      continue;
    }

    if (group != attr->group_tag)
    {
      group = attr->group_tag;

      putchar('\n');
      for (i = 2; i < indent; i ++)
        putchar(' ');

      printf("%s:\n\n", tags[group]);
    }

    for (i = 0; i < indent; i ++)
      putchar(' ');

    // print attributes
    //printf("%s (%s):", attr->name, tags[attr->value_tag]);
    printf("%s :", attr->name);

    switch (attr->value_tag)
    {
      case IPP_TAG_ENUM :

      // If the tag is an integer....

      case IPP_TAG_INTEGER :

   //----------------

          comparison1 = strcmp (attr->name, cmp_string1);
          comparison2 = strcmp (attr->name, cmp_string2);
          comparison3 = strcmp (attr->name, cmp_string3);

   //----------------


          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)

   //----------------

          if (comparison1 == 0) {

		printf(" (%d) %s" , val->integer, unix2date(val->integer)); 

           } else if (comparison2 == 0) {

		printf(" (%d) %s" , val->integer, unix2date(val->integer)); 

           } else if (comparison3 == 0) {

		printf(" (%d) %s" , val->integer, unix2date(val->integer)); 
	
         } else {

	  	printf(" %d", val->integer);

	  }
   //----------------

          putchar('\n');
          break;

      case IPP_TAG_BOOLEAN :
          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    printf(" %s", val->boolean ? "true" : "false");
          putchar('\n');
          break;

      case IPP_TAG_RANGE :
          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    printf(" %d-%d", val->range.lower, val->range.upper);
          putchar('\n');
          break;

      case IPP_TAG_DATE :
          {
	    time_t	vtime;		/* Date/Time value */
	    struct tm	*vdate;		/* Date info */
	    char	vstring[256];	/* Formatted time */

	    for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    {
	      vtime = ippDateToTime(val->date);
	      vdate = localtime(&vtime);
	      strftime(vstring, sizeof(vstring), "%c", vdate);
	      printf(" (%s)", vstring);
	    }
          }
          putchar('\n');
          break;

      case IPP_TAG_RESOLUTION :
          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    printf(" %dx%d%s", val->resolution.xres, val->resolution.yres,
	           val->resolution.units == IPP_RES_PER_INCH ? "dpi" : "dpc");
          putchar('\n');
          break;

      case IPP_TAG_STRING :
      case IPP_TAG_TEXTLANG :
      case IPP_TAG_NAMELANG :
      case IPP_TAG_TEXT :
      case IPP_TAG_NAME :
      case IPP_TAG_KEYWORD :
      case IPP_TAG_URI :
      case IPP_TAG_URISCHEME :
      case IPP_TAG_CHARSET :
      case IPP_TAG_LANGUAGE :
      case IPP_TAG_MIMETYPE :
          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    printf(" \"%s\"", val->string.text);
          putchar('\n');
          break;

      case IPP_TAG_BEGIN_COLLECTION :
          putchar('\n');

          for (i = 0, val = attr->values; i < attr->num_values; i ++, val ++)
	    print_attributes(val->collection, indent + 4);
          break;

      default :
          putchar('\n');
          break;
    }

  }
}
