//----------------------------------------------------------------------------
// 
void print_usage () {

	printf("\ncups_cache v1.0\n");
	printf("\nUsage:  cups_cache <cache filename> \n\n");
	exit;

}
//----------------------------------------------------------------------------
//
// Convert seconds since the epoch to char time.
//
char *unix2date (int mytime) {

	char *time_str = NULL;
	time_t timeval;
	timeval = mytime;

	time_str = strdup(ctime(&timeval));
        time_str[strlen(time_str) - 1] = '\0';
	return time_str;
}
//----------------------------------------------------------------------------
