/*
 * The MIT License
 *
 * Copyright 2018 Gustavo Rabelo <gustavo.vrr@gmail.com>.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import ij.*;
import ij.process.*;
import ij.gui.*;
import java.awt.*;
import ij.plugin.frame.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 *
 * @author Gustavo Rabelo <gustavo.vrr@gmail.com>
 */
public class Undistorter_ extends PlugInFrame {

    private BoxLayout layout = new BoxLayout((Container)this, BoxLayout.Y_AXIS);
    
    private JSlider sliderK1 = new JSlider();
    private JLabel labelK1 = new JLabel();
    private JSlider sliderK2 = new JSlider();
    private JLabel labelK2 = new JLabel();
    private JSlider sliderK3 = new JSlider();
    private JLabel labelK3 = new JLabel();
    private JLabel labelArrow = new JLabel();
    private JTextArea text1 = new JTextArea();
    private JTextArea text2 = new JTextArea();
    private JButton btnOptmize1 = new JButton();
    private JButton btnOptmize2 = new JButton();
    private ImageProcessor origIp=null;
    private ImageProcessor copyIp=null;
    private ImagePlus newImagePlus=null;
    private double k1min=0;
    private double k1max=0;
    private double k2min=0;
    private double k2max=0;
    private double k3min=0;
    private double k3max=0;
    private static final int NUM_TICKS = 50000;
    private double k1res=0;
    private double k2res=0;
    private double k3res=0;
    private int oldK1l=0;
    private int oldK2l=0;
    private int oldK3l=0;
    private int maxKl1=0;
    private int minKl1=0;
    private int maxKl2=0;
    private int minKl2=0;
    private int maxKl3=0;
    private int minKl3=0;
    private boolean suspendOperation = false;
    private int NUM_PROBES_K1 = 8;
    private int NUM_PROBES_K2 = 5;
    private int NUM_PROBES_K3 = 3;
    
    private boolean calculatingInitialBestValues = false;

    static private ScilabW sci ;

    private static void addJarToClasspath(File jar) throws NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, MalformedURLException {
        ClassLoader cl = ClassLoader.getSystemClassLoader();
        Method method = cl.getClass().getSuperclass().getDeclaredMethod("addURL", new Class[] {URL.class});
        method.setAccessible(true);
        method.invoke(cl, new Object[] {jar.toURI().toURL()});
    }
    
    private static void loadScilabJars()
    {
        String strSCI = System.getenv("SCI");
        if(strSCI == null || strSCI.trim().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Windows enviroment variable SCI not set");
            return;
        }
        if(!strSCI.endsWith(File.separator)) strSCI += File.separator;

        try
        {
            addJarToClasspath(new File(strSCI + "modules" + File.separator + "javasci" + File.separator + "jar" + File.separator + "org.scilab.modules.javasci.jar"));
            addJarToClasspath(new File(strSCI + "modules" + File.separator + "types" + File.separator + "jar" + File.separator + "org.scilab.modules.types.jar"));
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
            return;
        }
        
        File xmlFile = new File(strSCI + "etc"+File.separator+"classpath.xml");
        
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder=null;
        Document doc = null;
        try {
            dBuilder = dbFactory.newDocumentBuilder();
            doc = dBuilder.parse(xmlFile);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
            return;
        }
 
        NodeList nodeList = doc.getElementsByTagName("path");
        
        for(int n = 0; n<nodeList.getLength(); n++)
        {
            Node node = nodeList.item(n);
            Element eElement = (Element) node;
            if(eElement.getAttribute("load").equals(""))
            {
                String jarPath = eElement.getAttribute("value");
                jarPath = jarPath.replace("/", File.separator);
                jarPath = jarPath.replace("$SCILAB" + File.separator, strSCI);

                try {
                    addJarToClasspath(new File(jarPath));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                    return;
                }
            }
        }
        
    }
    
    public Undistorter_() {
        super("Undistorter");
    
        loadScilabJars(); //apparently, loading scilab jars changes the apparencies of swing controls
        
        try {
            if(sci == null)
            {   
                sci = new ScilabW();
                sci.open();
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
        }

        String s = getScilabFunctionsScript().toString();
        sci.exec(s);        
        
        initComponents();
        if(origIp==null)
                return;
        pack();
        GUI.center(this);
        setVisible(true);
        
    }

    private final void initComponents()
    {
            this.setLayout(layout);

            this.add(text1);
            this.add(sliderK1);
            this.add(labelK1);
            this.add(sliderK2);
            this.add(labelK2);
            this.add(sliderK3);
            this.add(labelK3);
            this.add(new JSeparator());
            this.add(labelArrow);
            this.add(new JSeparator());
            this.add(text2);
            this.add(btnOptmize1);
            this.add(btnOptmize2);

            text1.setRows(5);
            text1.setColumns(5);
            text1.setEditable(false);
            String explanation = "xu=xd/(1+ K1*r^2 + K2*r^4 + K3*r^6)\n";
            explanation += "yu=yd/(1 + K1*r^2 + K2*r^4 + K3*r^6)\n";
            explanation += "where:\n";
            explanation += "(xd,yd) = distorted image point as projected on image plane using specified lens,\n";

            explanation += "(xu,yu) = undistorted image point as projected by an ideal pinhole camera,\n";
            explanation += "r = sqrt(xu*xu + yu*yu)";
            text1.setText(explanation);

            labelK1.setText("K1=0");
            labelK1.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            labelK2.setText("K2=0");
            labelK2.setAlignmentX(Component.CENTER_ALIGNMENT);

            labelK3.setText("K3=0");
            labelK3.setAlignmentX(Component.CENTER_ALIGNMENT);

            
            labelArrow.setText("Arrow ratio = ");
            labelArrow.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            btnOptmize1.setAlignmentX(Component.CENTER_ALIGNMENT);
            btnOptmize2.setAlignmentX(Component.CENTER_ALIGNMENT);
            
            ImagePlus img = WindowManager.getCurrentImage();  // current image
            if(img == null)
            {
                    JOptionPane.showMessageDialog(null, "Open an image!");
                    this.setVisible(false);
                    this.close();
                    return;
            }
            origIp= img.getProcessor();
            copyIp = origIp.duplicate();
            newImagePlus= new ImagePlus("New window", copyIp);
            newImagePlus.show();


            int w=copyIp.getWidth();
            int h=copyIp.getHeight();

            double maxRu=w*w/4+h*h/4;
            maxRu=(double)Math.sqrt(maxRu);

            k1min=-(14.0f)/(maxRu*maxRu);
            k1max=(14.0f)/(maxRu*maxRu);

            k2min=-(14.0f)/(maxRu*maxRu*maxRu*maxRu);
            k2max=(14.0f)/(maxRu*maxRu*maxRu*maxRu);

            k3min=-(14.0f)/(maxRu*maxRu*maxRu*maxRu*maxRu*maxRu);
            k3max=(14.0f)/(maxRu*maxRu*maxRu*maxRu*maxRu*maxRu);
            
            
            maxKl1=(int)(NUM_TICKS*(k1max/(k1max-k1min)));
            minKl1=maxKl1-NUM_TICKS;
            sliderK1.setMaximum(maxKl1);
            sliderK1.setMinimum(minKl1);
            sliderK1.setValue(0);
            k1res = (k1max-k1min)/NUM_TICKS;
            
            maxKl2=(int)(NUM_TICKS*(k2max/(k2max-k2min)));
            minKl2=maxKl2-NUM_TICKS;
            sliderK2.setMaximum(maxKl2);
            sliderK2.setMinimum(minKl2);
            sliderK2.setValue(0);
            k2res = (k2max-k2min)/NUM_TICKS;

            maxKl3=(int)(NUM_TICKS*(k3max/(k3max-k3min)));
            minKl3=maxKl3-NUM_TICKS;
            sliderK3.setMaximum(maxKl3);
            sliderK3.setMinimum(minKl3);
            sliderK3.setValue(0);
            k3res = (k3max-k3min)/NUM_TICKS;
            
            
            sliderK1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    sliderK1StateChanged(evt);
             }
                    });

            sliderK2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    sliderK2StateChanged(evt);
             }
                    });

            sliderK3.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    sliderK3StateChanged(evt);
             }
                    });
            
            
            sliderK1.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(e.getButton()==MouseEvent.BUTTON3)
                        sliderK1.setValue(0);
                }
                @Override
                public void mousePressed(MouseEvent e) {
                }
                @Override
                public void mouseReleased(MouseEvent e) {
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                }
                @Override
                public void mouseExited(MouseEvent e) {
                }
            });

            sliderK2.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(e.getButton()==MouseEvent.BUTTON3)
                        sliderK2.setValue(0);
                }
                @Override
                public void mousePressed(MouseEvent e) {
                }
                @Override
                public void mouseReleased(MouseEvent e) {
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                }
                @Override
                public void mouseExited(MouseEvent e) {
                }
            });
            
            sliderK3.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if(e.getButton()==MouseEvent.BUTTON3)
                        sliderK3.setValue(0);
                }
                @Override
                public void mousePressed(MouseEvent e) {
                }
                @Override
                public void mouseReleased(MouseEvent e) {
                }
                @Override
                public void mouseEntered(MouseEvent e) {
                }
                @Override
                public void mouseExited(MouseEvent e) {
                }
            });

            
            text2.setRows(5);
            text2.setColumns(5);
            text2.setEditable(false);
            explanation = "For optimization create many segmented lines and add them to ROI Manager.\n";
            explanation += "Them the optimal K1, K2 and K3 will be find by trying to transform the segmented\n";
            explanation += "lines in straight lines.";
            text2.setText(explanation);

            btnOptmize1.setText("Optimize 1...");
            btnOptmize1.setToolTipText("Optimize using current K1, K2, K3 as initial values (fast)");
            btnOptmize1.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    btnOptimize1Click();
                }
            });
            
            btnOptmize2.setText("Optimize 2...");
            btnOptmize2.setToolTipText("Search for good K1, K2, K3 as initial values for optimization (slow)");
            btnOptmize2.addActionListener(new ActionListener() {

                @Override
                public void actionPerformed(ActionEvent e) {
                    btnOptimize2Click();
                }
            });
    }

    private void btnOptimize1Click()
    {
        optimize(1);
    }

    private void btnOptimize2Click()
    {
        new Thread(new Runnable() {

            @Override
            public void run() {
                sliderK1.setEnabled(false);
                sliderK2.setEnabled(false);
                sliderK3.setEnabled(false);
                btnOptmize1.setEnabled(false);
                btnOptmize2.setEnabled(false);
                optimize(2);
                sliderK1.setEnabled(true);
                sliderK2.setEnabled(true);
                sliderK3.setEnabled(true);
                btnOptmize1.setEnabled(true);
                btnOptmize2.setEnabled(true);
            }
        }).start();
        
    }
    
    
    private void sliderK1StateChanged(javax.swing.event.ChangeEvent evt) {                                      
            //labelK1.setText("K1=" + sliderK1.getValue()*k1res + "     k1l=" + sliderK1.getValue());
            labelK1.setText("K1=" + sliderK1.getValue()*k1res);
            transform();
    }

    private void sliderK2StateChanged(javax.swing.event.ChangeEvent evt) {                                      
            //labelK2.setText("K2=" + sliderK2.getValue()*k2res + "     k2l=" + sliderK2.getValue());
            labelK2.setText("K2=" + sliderK2.getValue()*k2res);
            transform();
    }

    private void sliderK3StateChanged(javax.swing.event.ChangeEvent evt) {                                      
            //labelK3.setText("K3=" + sliderK3.getValue()*k3res + "     k3l=" + sliderK3.getValue());
            labelK3.setText("K3=" + sliderK3.getValue()*k3res);
            transform();
    }
    
    private void transform()
    {
            if(suspendOperation) return;
            double k1=sliderK1.getValue()*k1res;
            double k2=sliderK2.getValue()*k2res;
            double k3=sliderK3.getValue()*k3res;

            int w=copyIp.getWidth();
            int h=copyIp.getHeight();

            int xc=w/2;
            int yc=h/2;

            int yd=0;
            int xd=0;
            int pixel;

            if(!calculatingInitialBestValues)
            {
                for(int xu=0; xu<w; xu++)
                {
                        for(int yu=0; yu<h; yu++)
                        {
                                double ru=0;
                                double rd=0;
                                ru=(double)Math.sqrt((xu-xc)*(xu-xc) + (yu-yc)*(yu-yc));
                                rd=ru*(1+ 
                                       k1*ru*ru+ 
                                       k2*ru*ru*ru*ru+
                                       k3*ru*ru*ru*ru*ru*ru);
                                yd=(int)Math.round(yc + (rd/ru)*(yu-yc));
                                xd=(int)Math.round(xc + (rd/ru)*(xu-xc));
                                pixel = origIp.getPixel(xd, yd);
                                copyIp.putPixel(xu, yu, pixel);
                        }
                }
            }
            
            
            //move segmented lines
            if(sci != null )
            {
                RoiManager rm = RoiManager.getRoiManager();
                ArrayList newrois = new ArrayList();
                
                
                //first of all, check for impossible solutions
                boolean impossibleSolution = false;
                for(int r=0; r<rm.getCount() && !impossibleSolution; r++)
                {
                    Roi roi = rm.getRoi(r);
                    
                    if(roi.getType() == Roi.POLYLINE)
                    {
                        PolygonRoi polyroi = (PolygonRoi)roi;
                        FloatPolygon fp = polyroi.getFloatPolygon();
                        
                        double oldK1 = oldK1l*k1res;
                        double oldK2 = oldK2l*k2res;
                        double oldK3 = oldK3l*k3res;
                        for(int p=0; p<fp.npoints && !impossibleSolution; p++)
                        {
                            //oldru->rd
                            double xu = fp.xpoints[p]-w/2;
                            double yu = fp.ypoints[p]-h/2;
                            double oldru = (double)Math.sqrt(xu*xu + yu*yu);
                            double rd = oldru*(1+
                                              oldK1*oldru*oldru+
                                              oldK2*oldru*oldru*oldru*oldru+
                                              oldK3*oldru*oldru*oldru*oldru*oldru*oldru);

                            //rd->rd (rounding xd and yd)
                            xd=(int)Math.round(rd/oldru*xu);
                            yd=(int)Math.round(rd/oldru*yu);
                            rd=(double)Math.sqrt(xd*xd + yd*yd);
                            
                            //rd->newru
                            ScilabDoubleW sci_rd = new ScilabDoubleW(rd);
                            ScilabDoubleW sci_k1 = new ScilabDoubleW(k1);
                            ScilabDoubleW sci_k2 = new ScilabDoubleW(k2);
                            ScilabDoubleW sci_k3 = new ScilabDoubleW(k3);
                            sci.put("rd", sci_rd);
                            sci.put("k1", sci_k1);
                            sci.put("k2", sci_k2);
                            sci.put("k3", sci_k3);
                            sci.exec("ru=findru(rd, k1, k2, k3);");
                            String strnewru = "0";
                            strnewru = sci.get("ru").toString().replace("[", "").replace("]", "");
                            if(strnewru.trim().equals(""))
                            {
                                impossibleSolution = true;
                                suspendOperation=true; 
                                sliderK1.setValue(oldK1l);
                                sliderK2.setValue(oldK2l);
                                suspendOperation=false;
                                sliderK3.setValue(oldK3l);
                            }
                            
                        }
                        
                    }

                }
                
                if(!impossibleSolution)
                {
                    for(int r=0; r<rm.getCount(); r++)
                    {
                        Roi roi = rm.getRoi(r);

                        if(roi.getType() == Roi.POLYLINE)
                        {
                            PolygonRoi polyroi = (PolygonRoi)roi;
                            FloatPolygon fp = polyroi.getFloatPolygon();


                            double oldK1 = oldK1l*k1res;
                            double oldK2 = oldK2l*k2res;
                            double oldK3 = oldK3l*k3res;
                            for(int p=0; p<fp.npoints; p++)
                            {
                                //oldru->rd
                                double xu = fp.xpoints[p]-w/2;
                                double yu = fp.ypoints[p]-h/2;
                                double oldru = (double)Math.sqrt(xu*xu + yu*yu);
                                double rd = oldru*(1+
                                                  oldK1*oldru*oldru+
                                                  oldK2*oldru*oldru*oldru*oldru+
                                                  oldK3*oldru*oldru*oldru*oldru*oldru*oldru);

                                //rd->rd (rounding xd and yd)
                                xd=(int)Math.round(rd/oldru*xu);
                                yd=(int)Math.round(rd/oldru*yu);
                                rd=(double)Math.sqrt(xd*xd + yd*yd);
                                        
                                //rd->newru
                                ScilabDoubleW sci_rd = new ScilabDoubleW(rd);
                                ScilabDoubleW sci_k1 = new ScilabDoubleW(k1);
                                ScilabDoubleW sci_k2 = new ScilabDoubleW(k2);
                                ScilabDoubleW sci_k3 = new ScilabDoubleW(k3);
                                sci.put("rd", sci_rd);
                                sci.put("k1", sci_k1);
                                sci.put("k2", sci_k2);
                                sci.put("k3", sci_k3);
                                sci.exec("ru=findru(rd, k1, k2, k3);");
                                String strnewru = "0";
                                strnewru = sci.get("ru").toString().replace("[", "").replace("]", "");
                                if(strnewru.trim().equals(""))
                                {
                                    //impossible solution
                                }
                                else
                                {
                                    double newru = Double.parseDouble(strnewru);
                                    double newxu = newru/rd * xd;
                                    double newyu = newru/rd * yd;
                                    
                                    fp.xpoints[p] = (float)(newxu + w/2);
                                    fp.ypoints[p] = (float)(newyu + h/2);
                                    if(k1==0 && k2==0 && k3==0)
                                    {
                                        fp.xpoints[p] = Math.round(fp.xpoints[p]);
                                        fp.ypoints[p] = Math.round(fp.ypoints[p]);
                                    }
                                }


                            }

                            Roi newRoi = new PolygonRoi(fp.xpoints.clone(), fp.ypoints.clone(), Roi.POLYLINE);
                            newrois.add(newRoi);

                        }

                    }
                    if(rm.getCount()>=1)
                    {
                        rm.reset();
                        for(int r=0; r<newrois.size(); r++)
                            rm.addRoi((PolygonRoi)(newrois.get(r)));

                        rm.runCommand("Show All");
                        
                        String strarrow = "" + getCurrentArrow();
                        //show arrow value to user
                        labelArrow.setText("Arrow ratio = "+strarrow);
                        
                    }
                
                }
            }
            
            
            newImagePlus.updateAndDraw();
            this.repaint();
            
            oldK1l=sliderK1.getValue();
            oldK2l=sliderK2.getValue();
            oldK3l=sliderK3.getValue();


    }

    private double getCurrentArrow()
    {
        int w=copyIp.getWidth();
        int h=copyIp.getHeight();
        ArrayList fps = mountFloatPolygonArray(); 
        StringBuilder strps = new StringBuilder();
        StringBuilder strns = new StringBuilder();
        mountStrpsStrns(strps, strns, fps, w, h);
        sci.exec(strps.toString());
        sci.exec(strns.toString());
        sci.exec("a=arrow_from_un([ ps ns  ]);"); //input is undistorted line segment
        String strarrow = sci.get("a").toString().replace("[", "");
        strarrow = strarrow.replace("]", "");
        try {
            return Double.parseDouble(strarrow);
        } catch(NumberFormatException ex){
            JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
            return -1;
        }
            

    }
    
    private void optimize(int nButton)
    {
        int w=copyIp.getWidth();
        int h=copyIp.getHeight();
        int kl1_init;
        int kl2_init;
        int kl3_init;
        
        //set kl1, kl2 and kl3 to zero just to return the initial values of segmented lines
        suspendOperation=true;
        sliderK1.setValue(0);
        sliderK2.setValue(0);
        suspendOperation=false;
        sliderK3.setValue(0);
        
        ArrayList fps = mountFloatPolygonArray();
        if(fps==null) return;
        
        if(fps.size()==0)
        {
            JOptionPane.showMessageDialog(null, "Must have at least one segmented line added to Roi Manager");
            return;
        }

        StringBuilder strps = new StringBuilder();
        StringBuilder strns = new StringBuilder();
        
        mountStrpsStrns(strps, strns, fps, w, h);
        
        sci.exec(getScilabLineDependentScript(strps.toString(), strns.toString()).toString());
        
        if(nButton == 1 )
        {
            kl1_init = sliderK1.getValue();
            kl2_init = sliderK2.getValue();
            kl3_init = sliderK3.getValue();
        }
        else
        {
            //find good initial values
            calculatingInitialBestValues = true;
            ArrayList candidates = new ArrayList();
            int delta1 = (maxKl1-minKl1)/NUM_PROBES_K1;
            int delta2 = (maxKl2-minKl2)/NUM_PROBES_K2;
            int delta3 = (maxKl3-minKl3)/NUM_PROBES_K3;
            for(int kl1 = minKl1 + delta1/2 ; kl1<maxKl1; kl1 += delta1)
                for(int kl2 = minKl2 + delta2/2 ; kl2<maxKl2; kl2 += delta2)
                    for(int kl3 = minKl3 + delta3/2 ; kl3<maxKl3; kl3 += delta3)
                    {
                        suspendOperation = true;
                        sliderK1.setValue(kl1);
                        sliderK2.setValue(kl2);
                        suspendOperation = false;
                        sliderK3.setValue(kl3);
                        //check if there is no impossible solutions
                        if(kl1==sliderK1.getValue() && kl2 == sliderK2.getValue() && kl3 == sliderK3.getValue())
                        {
                            double arrow = getCurrentArrow();
                            if(arrow >= 0)
                            {
                                double[] ballot = new double[]{arrow, kl1, kl2, kl3};
                                candidates.add(ballot);
                            }
                        }
                    }


            calculatingInitialBestValues = false;

            if(!candidates.isEmpty())
            {
                double[] winner = (double[])candidates.get(0);
                for(int i=1;i<candidates.size();i++)
                {
                    double[] candidate = (double[])candidates.get(i);
                    if(candidate[0] < winner[0]) //comparing arrow
                        winner = candidate;
                }
                kl1_init = (int)winner[1];
                kl2_init = (int)winner[2];
                kl3_init = (int)winner[3];
            }
            else
            {
                kl1_init = sliderK1.getValue();
                kl2_init = sliderK2.getValue();
                kl3_init = sliderK3.getValue();
            }
        }
        
        
        
        sci.exec(getScilabOptimizationScript(kl1_init, kl2_init, kl3_init).toString());
        
        //ScilabType fopt = sci.get("fopt");

        String str_xopt = sci.get("xopt").toString().replace("[", "").replace("]", "");
        String[] str_xopt_split = str_xopt.split(",");
        String str_k1l = str_xopt_split[0].trim();
        String str_k2l = str_xopt_split[1].trim();
        String str_k3l = str_xopt_split[2].trim();

        int k1l=(int)Math.round(Double.parseDouble(str_k1l));
        int k2l=(int)Math.round(Double.parseDouble(str_k2l));
        int k3l=(int)Math.round(Double.parseDouble(str_k3l));

        suspendOperation=true;        
        sliderK1.setValue(k1l);
        sliderK2.setValue(k2l);
        suspendOperation=false;
        sliderK3.setValue(k3l);

            

    }

    private ArrayList mountFloatPolygonArray()
    {
        ArrayList fps = new ArrayList();
        RoiManager rm = RoiManager.getRoiManager();
        for(int r=0; r<rm.getCount(); r++)
        {
            Roi roi = rm.getRoi(r);
            if(roi.getType() == Roi.POLYLINE)
            {
                PolygonRoi polyroi = (PolygonRoi)roi;
                FloatPolygon fp = polyroi.getFloatPolygon();
                if(fp.npoints < 3)
                {
                    JOptionPane.showMessageDialog(null, "All segmented lines must have at least 3 points.");
                    return null;
                }
                fps.add(fp);
            }
        }
        return fps;
    }

    
    private static StringBuilder getScilabFunctionsScript()
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append("function arms=areaRMS(d, h1, h2);");
        sb.append("T=d/3*(h1^2 + h2^2 + h1*h2);");
        sb.append("arms = sqrt(d*T);");
        sb.append("endfunction;");
        
        sb.append("function ru=findru(rd, k1, k2, k3);");
        sb.append("pol = [k3 0 k2 0 k1 0 1 -rd];");
        sb.append("root = roots(pol);");
        sb.append("indicies = find(0==imag(root) & real(root)>=0);");
        sb.append("ru=min(abs(root(indicies)));");
        sb.append("endfunction;");
        
        sb.append("function [a,pus]=arrow_from_dis(ps, ns, k1l, k2l, k3l, k1res, k2res, k3res);");
        sb.append("area=0;");
        sb.append("k1=k1l*k1res;");
        sb.append("k2=k2l*k2res;");
        sb.append("k3=k3l*k3res;");
        sb.append("d_total=0;");
        sb.append("pus=[];");
        sb.append("i=1;");
        sb.append("for n=ns;");
        sb.append("xds=ps(i:i+n-1);");
        sb.append("i=i+n;");
        sb.append("yds=ps(i:i+n-1);");
        sb.append("i=i+n;");
        sb.append("rds=xds.*xds + yds.*yds;");
        sb.append("rds=sqrt(rds);");
        sb.append("j=1;");
        sb.append("rus=[];");
        sb.append("for rd = rds;");
        sb.append("ru=findru(rd, k1, k2, k3);");
        sb.append("if(size(ru,1) == 0); a=%inf; pus=zeros(ps); return; end;");
        //sb.append("if(size(ru,1) == 0); a=10000; pus=zeros(ps); return; end;");
        sb.append("rus(1,j)=ru;");
        sb.append("j=j+1;");
        sb.append("end;");
        sb.append("xus = rus./rds .* xds;");
        sb.append("yus = rus./rds .* yds;");
        sb.append("pus = [pus xus yus];");
        sb.append("xus=xus';");
        sb.append("yus=yus';");
        sb.append("p = [xus, yus];");
        sb.append("p1 = p(1,1:2);");
        sb.append("p1 = repmat(p1,size(xus));");
        sb.append("p = p-p1;");
        sb.append("vn1 = p($,1:2);");
        sb.append("m = vn1 / sqrt(vn1(1)*vn1(1) + vn1(2)*vn1(2));");
        sb.append("n = [-m(2), m(1)];");
        sb.append("j=1;");
        sb.append("pl=[];");
        sb.append("for point=p';");
        sb.append("pl(j,1:2) = [m*point n*point];");
        sb.append("j=j+1;");        
        sb.append("end;");
        sb.append("sizepl = size(pl);");
        sb.append("for j=2:sizepl(1);");
        sb.append("d = pl(j,1)-pl(j-1,1);");        
        sb.append("d_total = d_total+d;");
        sb.append("h1 = pl(j-1,2);");
        sb.append("h2 = pl(j,2);");
        sb.append("area=area+areaRMS(d, h1, h2);");
        sb.append("end;");
        sb.append("end;");
        sb.append("a=area/d_total/d_total;");
        sb.append("endfunction;");
        
        sb.append("function a=arrow_from_un(ps, ns);");
        sb.append("area=0;");
        sb.append("d_total=0;");
        sb.append("pus=[];");
        sb.append("i=1;");
        sb.append("for n=ns;");
        sb.append("xus=ps(i:i+n-1);");
        sb.append("i=i+n;");
        sb.append("yus=ps(i:i+n-1);");
        sb.append("i=i+n;");
        sb.append("xus=xus';");
        sb.append("yus=yus';");
        sb.append("p = [xus, yus];");
        sb.append("p1 = p(1,1:2);");
        sb.append("p1 = repmat(p1,size(xus));");
        sb.append("p = p-p1;");
        sb.append("vn1 = p($,1:2);");
        sb.append("m = vn1 / sqrt(vn1(1)*vn1(1) + vn1(2)*vn1(2));");
        sb.append("n = [-m(2), m(1)];");
        sb.append("j=1;");
        sb.append("pl=[];");
        sb.append("for point=p';");
        sb.append("pl(j,1:2) = [m*point n*point];");
        sb.append("j=j+1;");        
        sb.append("end;");
        sb.append("sizepl = size(pl);");
        sb.append("for j=2:sizepl(1);");
        sb.append("d = pl(j,1)-pl(j-1,1);");        
        sb.append("d_total = d_total+d;");
        sb.append("h1 = pl(j-1,2);");
        sb.append("h2 = pl(j,2);");
        sb.append("area=area+areaRMS(d, h1, h2);");
        sb.append("end;");
        sb.append("end;");
        sb.append("a=area/d_total/d_total;");
        sb.append("endfunction;");
        
        return sb;
    }
    
    private StringBuilder getScilabLineDependentScript(String strps, String strns)
    {
        StringBuilder sb = new StringBuilder();
        
        
        sb.append("function a=arrow(x);");
        sb.append(strps);
        sb.append(strns);
        sb.append("k1res = " + k1res + ";");
        sb.append("k2res = " + k2res + ";");
        sb.append("k3res = " + k3res + ";");
        sb.append("a=arrow_from_dis(ps,ns,x(1),x(2),x(3),k1res,k2res,k3res);");
        sb.append("a=log10(a)+2000;");
        sb.append("endfunction;");
        
        
        return sb;
    }

    private StringBuilder getScilabOptimizationScript(int kl1_init, int kl2_init, int kl3_init)
    {
        StringBuilder sb = new StringBuilder();
        
        sb.append("[fopt,xopt] = leastsq(arrow, 'b', [" + minKl1 + ", " + minKl2 + ", " + minKl3 +"], [" + maxKl1 + ", " + maxKl2 + ", " + maxKl3 + "], ["+kl1_init+" "+kl2_init+" " + kl3_init + "]);");
        
        return sb;
    }
    
    
    private static void mountStrpsStrns(StringBuilder strps, StringBuilder strns, ArrayList fps, int w, int h) {
        strps.append("ps = [ ");
        strns.append("ns = [ ");
        
        for(int i=0; i<fps.size(); i++)
        {
            FloatPolygon fp = (FloatPolygon)fps.get(i);
            String strX="";
            String strY="";

            for(int p=0; p<fp.npoints; p++)
            {
                strX += fp.xpoints[p]-w/2 + " ";
                strY += fp.ypoints[p]-h/2 + " ";
            }
            strps.append( strX + strY );
            strns.append( fp.npoints + " ");
        }

        
        strps.append( " ];" );
        strns.append( " ];" );
        
    }
    
    private class ScilabW
    {
        private final Object scilab;
        private final Method mExec;
        private final Method mOpen;
        private final Method mPut;
        private final Method mGet;
        private final Method mClose;
        
        public ScilabW()
        {
            Object scilab_;
            Method mExec_;
            Method mOpen_;
            Method mPut_;
            Method mGet_;
            Method mClose_;
            
            try {
                scilab_ = Class.forName("org.scilab.modules.javasci.Scilab").newInstance();
                mExec_ = scilab_.getClass().getMethod("exec", String.class);
                mOpen_ = scilab_.getClass().getMethod("open");
                mPut_ = scilab_.getClass().getMethod("put", String.class, Class.forName("org.scilab.modules.types.ScilabType"));
                mGet_ = scilab_.getClass().getMethod("get", String.class);
                mClose_ = scilab_.getClass().getMethod("close");
            } catch (Exception ex) {
                scilab_ = null;
                mExec_ = null;
                mOpen_ = null;
                mPut_ = null;
                mGet_ = null;
                mClose_ = null;
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
            }
            scilab = scilab_;
            mExec = mExec_;
            mOpen = mOpen_;
            mPut = mPut_;
            mGet = mGet_;
            mClose = mClose_;
        }
        
        public synchronized boolean exec(String cmd)
        {
            try {
                Object r = mExec.invoke(scilab, cmd);
                return (Boolean)r;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                return false;
            }
        }
        
        public Boolean open()
        {
            close();
            
            try {
                Object r = mOpen.invoke(scilab);
                return (Boolean)r;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                return false;
            }
        }

        public Boolean close()
        {
            try {
                Object r = mClose.invoke(scilab);
                return (Boolean)r;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                return false;
            }
        }

        
        public void put(String var, ScilabDoubleW val)
        {
            try {
                mPut.invoke(scilab, var, val.getWrappedObj());
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
            }
            
        }

        public Object get(String var)
        {
            try {
                Object r = mGet.invoke(scilab, var);
                return r;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                return null;
            }
        }
        
        public Object getWrappedObj()
        {
            return scilab;
        }
    }
    
    private class ScilabDoubleW
    {
        private final Object scilabDouble;
        
        public ScilabDoubleW(double d)
        {
            Object scilabDouble_;
            try {
                scilabDouble_ = Class.forName("org.scilab.modules.types.ScilabDouble").getDeclaredConstructor(double.class).newInstance(d);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, Thread.currentThread().getStackTrace()[2].getLineNumber() + " " + ex.toString());
                scilabDouble_ = null;
            }
            
            scilabDouble = scilabDouble_;
            
        }
        
        public Object getWrappedObj()
        {
            return scilabDouble;
        }
        
    }
}