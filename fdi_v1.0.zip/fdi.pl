#!/usr/bin/perl
use strict;
use Getopt::Long;
use XML::Parser;
use Date::Manip::Date;

my $parser = new XML::Parser;
 
my ($help, $file, $search,$filterN, $list, $num);
my %regExHash=();
my @sortorder;
my $listfilters;

my ($count,$tag,%attrs);
my $line;
my $match;
my $result;
my $data;
my $searchFound;
my $linenum;

#timeframe vars
my $dateManip=new Date::Manip::Date;
my $begindate;
my $enddate;
my $dateformat;
my $dformat;
my $err;
my $bval;
my $eval;
my $bsec;
my $esec;
my $bdate=new Date::Manip::Date;
my $edate=new Date::Manip::Date;
my $val;
my $sec;

my $xmlfile = "fdiConfig.xml";

#get all switches and their values
GetOptions('help:o' => \$help,
           'file:s' => \$file,
           'search=s' => \$search, 
           'begindate:s' => \$begindate,
           'enddate:s' => \$enddate,
           'dateformat:s' => \$dformat,
           'num' => \$linenum,
           'list' => \$listfilters);
#help banner
sub banner
{
 print "Unknown argument: @_\n" if ( @_ );
 print "Forensics Data Identifier v1\.0 2011 created by Gain Georgiev\n";
 print "This tool will filter out any data from STDIN or optional file\nfor any matching forensically relevent data paterns.\n\n";
 print "fdi --search [required filter or group filter or \"all\"]\n";
 print "       -s or --search [ required filter or group filter or \"all\"]\n";
 print "       -b or --begindate [optional date in the format specified within dataformat]\n";
 print "       -e or --enddate [optional date in the format specified within dataformat]\n";
 print "       -d or --dateformat [optional date pattern format using printf values. For example: \"%Y\\-%m\\-%d %T\" will match YYYY-MM-DD HH:MM:SS]\n";
 print "       -f or --file [optional file to parse]\n";
 print "       -n or --num [optional list the line number for any results]\n";
 print "       -l or --list [optional list available filters within fdiConfig.xml]\n";
 print "       -h or --help\n";
 print "       \n";
 print "       \n";
 print " Usage 1 - Filter STDIN for the \"pii\" group of defined data patterns\n";
 print "       cat datafile.log | perl fdi.pl -s pii\n";
 print "       \n";
 print " Usage 2 - Filter a specified file for all defined patterns \n";
 print "       perl fdi.pl -s all -f datafile.log\n";
 print "       \n";
 print " Usage 3 - Filter STDIN for any lines having a timestamp in the format YYYY-MM-DD HH:MM:SS\n"; 
 print "                AND between the timeframe of 2005-04-11 08:04:58-2005-04-11 08:09:59 \n";
 print "                AND having an email data type\n";
 print "       cat datafile.log| perl fdi.pl -s email -b \"2005-04-11 08:04:58\" -e \"2005-04-11 08:09:59\" --dateformat \"%Y\\-%m\\-%d %T\"\n";
 print "       \n";
 print " Usage 4 - List all available groups and their corresponding filters defined within fdiConfig.xml\n";
 print "       perl fdi.pl -list\n";
 print "       \n";
 print "       \n";
 exit;
}
#var used to track if matched search term
$searchFound="";

if($listfilters){
print "Below is a list of all avilable groups and their filters defined within fdiConfig.xml\n";
print "To search you can use an individual filter name, group name or just the word <all> to search for all\n\n";
print "groups\t\tfilters\n";  
print "----------------------------------------------------------\n"     
}
#inline XML config parsing function
sub startElement {
      
      my( $parseinst, $element, %attrs ) = @_;
         SWITCH: {
                #when the group is found set groupState var to found or if listfilter is set just print the group name
                if (($element eq "group") and (($attrs{'name'} eq $search) or ($listfilters))) {
                        
                       if($listfilters){
                            
                         print "\n$attrs{'name'}\n\n";
                         
                        }
                        
                       else{
                               
                       
                        $tag = "group";
                        $searchFound="yes";
                        last SWITCH;
                        
                        }
                       
                }
                #when the group is NOT found reset the groupState
                if(($element eq "group") and not ($attrs{'name'} eq $search)) {
                        $searchFound="";
                        last SWITCH;
                }
                #if element is filter just get the name value 
                if ($element eq "filter") {
                        #print "Filter: ";
                        $tag = "filter";
                        $filterN=$attrs{'name'};
                        
                        last SWITCH;
                }
               
                
        }

 }

#parse the end element
sub endElement {
        
      my( $parseinst, $element ) = @_;
        if (($element eq "group")and ($attrs{'name'} eq $search)) {
                $searchFound="";
                
        } 

 }

#parse the data values
sub characterData {

      my( $parseinst, $data ) = @_;
        #if group was found, search is "all" or individual filter matches the search get store the key value pair in the hash
        if (($tag eq "filter") and (($searchFound eq "yes") or ($search eq "all") or ($search eq $filterN) or ($listfilters))) {
             
            if ( not $regExHash{$filterN}){
                     if ($listfilters){
                       
                         print "\t\t$filterN\n";
                         $regExHash{$filterN}=$data;
                      }      
                      else{
                        #eliminate any duplicates
                       
                          # replace any "gt" and "lt" with their appropriate < and > characters 
                          $data =~ s/gt/>/g;   
                          $data =~ s/lt/</g;   
                          $data =~ s/amp/&amp/g;
                          #store the values in a unordered hash                              
                          $regExHash{$filterN}=$data;
                          
                          #store the values in sorted array
                          @sortorder = sort keys %regExHash;  
                                           
                      }
             }
                
               
        }
        

 }

sub default {

      my( $parseinst, $data ) = @_;
        # do nothing, but stay quiet

 }
 
sub configReader{

#check if config file exists
die "Cannot find file \"$xmlfile\""
       unless -f $xmlfile;



$tag = "";

$parser->setHandlers(                    Start => \&startElement,
                                         End => \&endElement,
                                         Char => \&characterData,
                                         Default => \&default);

$parser->parsefile($xmlfile);
}


#parse config if list was provided as an option
if ($listfilters) {
  configReader();
}

#prints banner if no command line parameters are passed or there is an unknown argument or help is passed
if ($search){
  configReader();
  
  #read from STDIN
  if ($file eq "") {
    $data =*STDIN;
  
  #read from file
  }else{
    open $data, "<", $file or die $!;
  }
   $bsec="";
   $esec="";
   #if begin and end date are set convert them to sec since UNIX epoch
   if (!($begindate eq "" and $enddate eq "" and $dformat eq "")){
           
          
                
                print "Begin: $begindate End: $enddate\n";
                $err = $bdate->parse_format($dformat,$begindate); 
                $err = $edate->parse_format($dformat,$enddate);       
                $bsec = $bdate->secs_since_1970_GMT();
                $esec = $edate->secs_since_1970_GMT();
                
                #$bval = $bdate->value();
                #$eval = $edate->value(); 
                #print "Begin: $bval End: $eval\n";
               
    }
    $count = 0;
    #read each line from the handler
    foreach $line (<$data>){
                
                #keep count of the lines
                $count++;
                
                #reset match on new line to avoid dups
                $match=0; 
                
				#if no dates then don't parse the line for timestamps
				if (!($begindate eq "" and $enddate eq "" and $dformat eq "")){
                #parse the timestamp value from the line                               
                $err = $dateManip->parse_format(".*$dformat.*",$line);
                
                #verify if timestamp was found and if so convert to sec since UNIX epoch
                if (!($err == 1)){
                       
                        $sec = $dateManip->secs_since_1970_GMT();
                        
                        #$val = $dateManip->value();
                        #print "ERROR: $err\n";
                        #print "DATE: $val\n";   
                }
                else{
                        $sec=0;
                }
				}
                
                #only search the line if timestamp is within the range or no timestamp was specified
                if (($bsec eq "" and $esec eq "") or ($esec >= $sec and $sec >= $bsec  )){
                        
                        
                       #loop through each one of the sorted filters
                       foreach my $key (@sortorder){
                            
                            #get the regex expression for the filter
                            my $value = $regExHash{$key};
                           
                            #clear end line character   
                            chomp($line);
                            
                            #if the regex have a match AND no previous matches
                            if(($line=~m/$value/i and $match == 0)){
                                    
                                    if ($linenum){
                                                                                
                                        print "$count $key: $line\n";
                                        
                                    }
                                    else {
                                        print "$key: $line\n";  
                                    }
                                        
                                        #set to one if we have a match
                                        $match=1;     
                                 }
                            }
                }
                   
        }        
    #close STDIN or FILE handle
    close($data);
        
    exit;
}
elsif (!($listfilters)) {
  banner();
  
}
