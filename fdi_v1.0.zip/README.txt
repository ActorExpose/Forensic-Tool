1.	Introduction
---------------------------------------------------------------------------------------------------------------------------
The Forensics Data Identifier (FDI) is a tool which allows for large data files to be easily filtered for common forensically relevant data types. The tool was intended to speed up the e-discovery and analysis processes of the forensics investigation.
FDI will parse the data feed line by line and will find any data which matches the patterns defined within the fdiConfig.xml. To find these data formats the tool uses several pre-defined regex filters. They are organized in groups which allow for multiple filters to be used at the same time. In addition, if the lines in the input file contain timestamps the tool also allows filtering the data for a specific timeframe.
It is important to note that FDI doesn�t come with any warranty and guarantees and it is possible for the tool to produce false positives or to miss certain data. The tool was designed to augment the manual analysis and discovery processes and to assist the investigator with the manual effort. The tool should not be used as a single way and means to uncover forensically relevant data.

2.	Dependencies
--------------------------------------------------------------------------------------------------------------------------
Perl v5.1 and up
CPAN v1.9 and up
Perl Module(s): Date::Manip v6.23 and up

3. 	Download Link
----------------------------------------------------------------------------------------------------------------------------
http://sourceforge.net/projects/fdi/files/fdi_v1.0.zip/download


4.	Installation 
----------------------------------------------------------------------------------------------------------------------------
Linux (Ubuntu v10)
3.1 Install perl and cpan
In most linux distributions perl and cpan are pre-installed so you don�t have to install these. Yet, to confirm that both are installed and satisfy the version dependencies listed above run the following:
perl �v

cpan �v

4.2 Install perl module
The Date::Manip perl module will most likely be missing so to install this one follow these steps.
Start the cpan shell by running the following:
cpan

Download and install Date:Manip perl module by running the following within the cpan shell:
install Date::Manip
	3.3 Install FDI
Download and extract the FDI tool and it�s config file (fdiConfig.xml) in the same folder. Change the fdi.pl 

Windows (32bit XP and 64bit 7)
4.4	Install Perl
Download and install Strawberry Perl v5.10 and up from the link below.
http://strawberryperl.com/

4.5	Install perl module
Start a command line window ( on Windows 7 start it as  administrator.)
Next, start the cpan shell by running the following:

cpan

Finally, within the cpan shell install the Date::Manip perl module y running the following:

install Date::Manip

NOTE: On Win 7 if you encounter any permission errors with FTPstats.yml you need to change the permissions on the C:\Perl64\cpan folder and allow Everyone to have full control of the folder. Than simply re-run the install Date::Manip and it should work.
	
5.	How to use it
-----------------------------------------------------------------------------------------------------------------------------
Below is a list of different ways the tool can be used to filter out certain data types from either a STDIN or a file provided as an argument. It is important to note that if multiple filters are used (for example group or all) the FDI tool will only report the first matching pattern found on the line.

 Usage 1 � In this example the tool will filter STDIN for the "pii" group of defined data patterns. The pii group and its corresponding data 			filters are defined within fdiConfig.xml.

       cat datafile.log | perl fdi.pl -s pii
       
 Usage 2 - Filter a specified file for all defined patterns within fdiConfig.xml. Further because �-n� option is specified the tool will also 		list the line number for every matching line.

       perl fdi.pl -s all -f datafile.log
       
 Usage 3 - Filter STDIN for any lines having a timestamp in the format YYYY-MM-DD HH:MM:SS
                AND between the timeframe of 2005-04-11 08:04:58-2005-04-11 08:09:59 
                AND having an email data type

       cat datafile.log| perl fdi.pl -s email -b "2005-04-11 08:04:58" -e "2005-04-11 08:09:59" --dateformat "%Y\-%m\-%d %T"
       
 Usage 4 - List all available groups and their corresponding filters defined within fdiConfig.xml

       perl fdi.pl �list


6.	Provide feedback and report any bugs
-----------------------------------------------------------------------------------------------------------------------------

Please feel free to provide any feedback and report any bugs to me via galingv@gmail.com so I can keep improving the tool. This was my first Perl project, so I�m expecting to have few bugs here and there. Also, feel free to submit any suggestions and recommendations on how the FDI tool can be improved.

7.	About the author
-----------------------------------------------------------------------------------------------------------------------------
Although I have some experience in writing Java this was my first Perl project. I enjoy software development because it challenges one to be creative and allows them to provide unique solutions to complex problems. I believe that it is essential for security professionals to stay creative in order to be effective against the ever changing security threats. The field of IT security continues to mature, yet so are the attacks the perpetrators use to circumvent any of our security measures. 

8.	References and Credits
-----------------------------------------------------------------------------------------------------------------------------
I want to give special thanks to Prof. Joseph Vela who gave the idea for the time filter and have made several other suggestions on how to improve the FDI tool. Also, I would like to thank the community and numerous people who contributed with their regular expressions to regexlib.com as several of the filters were obtained from there. 
 

8.	End User License
-----------------------------------------------------------------------------------------------------------------------------
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; version 3 
of the License, or (at your option) any later version. 

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. 

You should have received a copy of the GNU General Public License 
along with this program; if not, write to the Free Software 
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
or view it online at http://www.gnu.org/licenses/gpl.html
