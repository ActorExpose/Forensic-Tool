REQUIRES .NET 2.0 or higher

RUN WHICH_VERSION.BAT IF YOU ARE UNSURE WHICH VERSION TO RUN.

-----------
Switches:
-----------
Arguments:
/ext:<extension list> - only copy files who's extensions match the comma separated list
/regx:<regular expression> - only copy files who's name matches the regex
/f - attempt to copy locked files with Volume Shadow Copy
/v - verify the files after copying - skipped files attempt to verify
/flat - copy all files to the output directory (no folder structure)
/h0 - don't copy hidden or system files or folders
/hd0 - don't copy hidden or system directories or their contents
/hf0 - don't copy hidden or system files
/e0 - don't copy empty folders
/p - copy file/folder permissions
/ps - copy permissions without inheritance from destinaiton folder
/prompt - enable prompting if current user doesn't have permissions
/so - copy directory structure only
/t0 - don't preserve any file times (same as /tw0 /ta0 /tc0)
/tw0 - don't preserve last written times
/ta0 - don't preserve last accessed times
/tc0 - don't preserve creation times
/r - replace existing files
/list - list all file and folder information for a given directory
/tovmdk - creates a vmdk file for an existing dd image (single file or split)
/dd - create a bit stream backup of a drive
/out:<output format> - specify output format for dd stream (iso, split, single, vmdk)
/chkp - check for errors and permissions needed if copy were to occur (NO COPYING DONE)
/listvols - list valid volumes for /dd switch
/listdrives - list valid physical drives for /dd switch
/hash - computes a hash list for a file or all files in directory
        no destination needed if input a is file
/rhash - computes a reporting hash for top level verification

-----------
Examples:
-----------
Command: filecopytool.exe H:\test C:\Destination
End Result: C:\Destination\test created : all files/folders copied into it
preserving timestamps and attributes - log file stored at C:\Destination

Command: filecopytool.exe /ext:xlsx,txt H:\test C:\Destination
End Result: C:\Destination\test created : all files with txt or xlsx extensions 
and all folders copied into it preserving timestamps and attributes - log file 
stored at C:\Destination

Command: filecopytool.exe H:\test C:\Destination
End Result: C:\Destination\test created : all files and non-empty folders copied into it
preserving timestamps and attributes - log file stored at C:\Destination

Command: filecopytool.exe /ext:xlsx,txt /e0 H:\test C:\Destination
End Result: C:\Destination\test created : all files with txt or xlsx extensions 
and all folders copied into it preserving timestamps and attributes - log file 
stored at C:\Destination

Command: filecopytool.exe /regx:*.log H:\test C:\Destination
End Result: C:\Destination\test created : all files matching regex 
and all folders copied into it preserving timestamps and attributes - log file 
stored at C:\Destination

Command: filecopytool.exe /v H:\test C:\Destination
End Result: C:\Destination\test created : all files/folders copied into it
preserving timestamps and attributes - log file stored at C:\Destination - hash
verification for each file stored at C:\Destination

Command: filecopytool.exe /flat H:\test C:\Destination
End Result: all files copied into C:\Destination
preserving timestamps and attributes - log file stored at C:\Destination files with same
name have unique numbers appended to filename.

Command: filecopytool.exe /hash H:\HashMe.txt
End Result: HashMe.txt.hash created alongside file

Command: filecopytool.exe /hash H:\test C:\log.txt
End Result: Hashes all files in H:\test and logs results to file specified

Command: filecopytool.exe /hash H:\test C:\Destination
End Result: Hashes all files in H:\test and logs results to HashList.txt in C:\Destination

Command: filecopytool.exe /v /rhash H:\test C:\Destination
End Result: C:\Destination\test created : all files/folders copied into it
preserving timestamps and attributes - log file stored at C:\Destination - hash
verification for each file stored at C:\Destination - reporting hash (hash of all hash values)
stored in log - useful for forms etc

Command: filecopytool.exe /h0 H:\test C:\Destination
End Result: Skips hidden or system files and folders otherwise same as example 1

Command: filecopytool.exe /hd0 H:\test C:\Destination
End Result: Skips hidden or system folders otherwise same as example 1

Command: filecopytool.exe /hf0 H:\test C:\Destination
End Result: Skips hidden or system files otherwise same as example 1

Command: filecopytool.exe /p H:\test C:\Destination
End Result: Copies file/folder permissions (with destination inheritance) otherwise same 
as example 1

Command: filecopytool.exe /ps H:\test C:\Destination
End Result: Copies file/folder permissions (without! destination inheritance) otherwise same 
as example 1

Command: filecopytool.exe /prompt H:\test C:\Destination
End result: Same as example 1 except a prompt appears for files that can't be accessed by the 
running user. Options to copy as owner, reset password then copy, or skip.

Command: filecopytool.exe /so H:\test C:\Destination
End result: Only copies the directory structure, no files

Command: filecopytool.exe /t0 H:\test C:\Destination
End result: Doesn't preserve any timestamps - preserves attributes still

Command: filecopytool.exe /tw0 H:\test C:\Destination
End result: Doesn't preserve last written timestamps - preserves attributes and other timestamps still

Command: filecopytool.exe /ta0 H:\test C:\Destination
End result: Doesn't preserve last accessed timestamps - preserves attributes and other timestamps still

Command: filecopytool.exe /tc0 H:\test C:\Destination
End result: Doesn't preserve created timestamps - preserves attributes and other timestamps still

Command: filecopytool.exe /r H:\test C:\Destination
End Result: Same as example 1 except files existing in destination are not skipped but replaced

Command: filecopytool.exe /list H:\test C:\Destination
End Result: Creates a file listing csv in C:\Destination containing paths and metadata info

Command: filecopytool.exe /chkp H:\test C:\Destination
End Result: Goes through the motions of copying without actually copying and checks for permissions and 
other errors. Will also provide a list of users who control files you can't access

Command: filecopytool.exe /listvols
End Result: Displays a list of volumns that can be the source of a /dd command

Command: filecopytool.exe /listdrives
End Result: Displays a list of physical disks that can be the source of a /dd command

Command: filecopytool.exe /tovmdk H:\test C:\Destination
End Result: Creates a vmdk file for the DD image in H:\test and places it in C:\Destination
NOTE: Works best when DD files are the only files in the source path (no logs etc) but should work if
logs are there

Command: filecopytool.exe /dd PhysicalDrive7 C:\Destination
End Result: Creates a bit copy (dd image) of PhysicalDrive7 split into 2 GB chunks and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:split PhysicalDrive7 C:\Destination
End Result: Creates a bit copy (dd image) of PhysicalDrive7 split into 2 GB chunks and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:iso PhysicalDrive7 C:\Destination
End Result: Creates a bit copy (dd image) of PhysicalDrive7 into a ISO and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:single PhysicalDrive7 C:\Destination
End Result: Creates a bit copy (dd image) of PhysicalDrive7 into single file and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:vmdk PhysicalDrive7 C:\Destination
End Result: Creates a bit copy (dd image) of PhysicalDrive7 and creates a vmdk file for it then
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd D: C:\Destination
End Result: Creates a bit copy (dd image) of the D volume split into 2 GB chunks and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:split D: C:\Destination
End Result: Creates a bit copy (dd image) of D volume split into 2 GB chunks and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:iso D: C:\Destination
End Result: Creates a bit copy (dd image) of D volume into a ISO and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:single D: C:\Destination
End Result: Creates a bit copy (dd image) of D volume into single file and
places them in C:\Destination after prompting for a filename

Command: filecopytool.exe /dd /out:vmdk D: C:\Destination
End Result: Creates a bit copy (dd image) of D volume and creates a vmdk file for it then
places them in C:\Destination after prompting for a filename