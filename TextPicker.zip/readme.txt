Dependencies:

Java 8;
OpenCV installed (see https://opencv.org/license.html);
Tesseract installed (see https://github.com/tesseract-ocr/tesseract/blob/master/LICENSE).
--------------------------------------------------

Before using, add to Windows path:

The bin directory inside OpenCV (e.g. C:\opencv\build\bin;)
The java dll directory inside OpenCV (e.g. C:\opencv\build\java\x64;)
The Tesseract directory (e.g. C:\Program Files (x86)\Tesseract-OCR;)

--------------------------------------------------

How to run:

java -jar TextPicker.jar (or double click this file)

--------------------------------------------------

Tested with:

OpenCV 3.4.1 - https://sourceforge.net/projects/opencvlibrary/files/opencv-win/3.4.1/opencv-3.4.1-vc14_vc15.exe/download
Tesseract 3.05 - http://digi.bib.uni-mannheim.de/tesseract/tesseract-ocr-setup-3.05.01.exe
Windows 7,8,10

--------------------------------------------------

The software TextPicker is distributed under the terms of MIT License:


The MIT License

Copyright 2018 Gustavo Rabelo <gustavo.vrr@gmail.com>.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
